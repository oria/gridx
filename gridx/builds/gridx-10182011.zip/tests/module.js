define([], function(){

doh.registerUrl("gridx.tests.robot.pagination", dojo.moduleUrl("gridx", "tests/doh/pagination.html"));
//doh.registerUrl("gridx.tests.robot.singleSort", dojo.moduleUrl("gridx", "tests/robot/singleSort.html"));
//doh.registerUrl("gridx.tests.robot.nestedSort", dojo.moduleUrl("gridx", "tests/robot/nestedSort.html"));
//doh.registerUrl("gridx.tests.robot.extendedSelect", dojo.moduleUrl("gridx", "tests/robot/extendedSelect.html"));
//doh.registerUrl("gridx.tests.robot.persist", dojo.moduleUrl("gridx", "tests/robot/persist.html"));
//doh.registerUrl("gridx.tests.robot.menu", dojo.moduleUrl("gridx", "tests/robot/menu.html"));
//doh.registerUrl("gridx.tests.robot.columnLock", dojo.moduleUrl("gridx", "tests/robot/columnLock.html"));
//doh.registerUrl("gridx.tests.robot.columnResizer", dojo.moduleUrl("gridx", "tests/robot/columnResizer.html"));


});



