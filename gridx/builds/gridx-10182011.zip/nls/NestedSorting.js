define({ root:

({
	singleSort: "Single Sort",
	nestedSort: "Nested Sort",
	ascending: "Click to sort Ascending",
	descending: "Click to sort Descending",
	sortingState: "${0} - ${1}",
	unsorted: "Do not sort this column"
})

});
